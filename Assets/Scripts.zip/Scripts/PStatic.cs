using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class PStatic
{
    public static int point = 0;
}